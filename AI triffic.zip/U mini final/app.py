from flask import Flask, render_template, request
import numpy as np
import joblib

app = Flask(__name__)

# Load the saved model and scaler
model = joblib.load('traffic_model.pkl')
scaler = joblib.load('scaler.pkl')

@app.route('/', methods=['GET', 'POST'])
def home():
    return render_template("home.html")

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    prediction = None

    if request.method == 'POST':
        try:
            day = int(request.form['day'])
            vehicle_count = float(request.form['vehicle_count'])
            temperature = float(request.form['temperature'])
            humidity = float(request.form['humidity'])

            features = [day, vehicle_count, temperature, humidity]
            scaled = scaler.transform([features])
            result = model.predict(scaled)[0]
            print(result)
            # Example thresholds (customize based on training data)
            # Interpret result
            if result < 1.5:
                level = "Low"
                message = "Smooth traffic, enjoy your ride!"
            elif result < 2:
                level = "Moderate"
                message = "Expect some delays, stay alert."
            elif result < 3:
                level = "High"
                message = "Heavy traffic, consider alternate routes."
            else:
                level = "Severe"
                message = "Avoid travel if possible, consider remote options."

            return render_template('result.html', level=level, message=message,vehicle_count=vehicle_count)
        except Exception as e:
            prediction = f"Error: {str(e)}"

    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
